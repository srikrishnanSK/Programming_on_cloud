# poc-f-2020-be
This repo is backend for the Coen 6313 Project, Group 2.
This spring boot app is hosted on Google App engine.
This spring baoot app, contains rest urls, which are exposed.The front end (ReactJS) will request to these URLs.
Depending upon the request, content will be served and processed.

